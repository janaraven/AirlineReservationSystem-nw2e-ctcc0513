import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedList;
import java.util.Queue;

public class AirlineReservationSystem extends JFrame {
    private int availableSeats;
    private Queue<String> reservationQueue;
    private JTextArea outputTextArea;

    public AirlineReservationSystem(int totalSeats) {
        this.availableSeats = totalSeats;
        this.reservationQueue = new LinkedList<>();

        setTitle("Airline Reservation System");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        createGUI();
    }

    private void createGUI() {
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());

        outputTextArea = new JTextArea();
        outputTextArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(outputTextArea);
        panel.add(scrollPane, BorderLayout.CENTER);

        JButton reserveButton = new JButton("Make Reservation");
        reserveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String passengerName = JOptionPane.showInputDialog("Enter passenger name:");
                if (passengerName != null && !passengerName.trim().isEmpty()) {
                    makeReservation(passengerName);
                }
            }
        });

        JButton processButton = new JButton("Process Waiting List");
        processButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                processWaitingList();
            }
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(reserveButton);
        buttonPanel.add(processButton);

        panel.add(buttonPanel, BorderLayout.SOUTH);

        add(panel);
    }

    private synchronized void makeReservation(String passengerName) {
        if (availableSeats > 0) {
            availableSeats--;
            outputTextArea.append("Reservation for " + passengerName + " successful. Remaining seats: " + availableSeats + "\n");
        } else {
            outputTextArea.append("Sorry, no more seats available. Adding " + passengerName + " to the waiting list.\n");
            reservationQueue.add(passengerName);
        }
    }

    private synchronized void processWaitingList() {
        while (!reservationQueue.isEmpty() && availableSeats > 0) {
            String passengerName = reservationQueue.poll();
            availableSeats--;

            // Update GUI on the Event Dispatch Thread
            SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                    outputTextArea.append("Reservation for " + passengerName + " from waiting list successful. Remaining seats: " + availableSeats + "\n");
                }
            });
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                AirlineReservationSystem gui = new AirlineReservationSystem(50);
                gui.setVisible(true);
            }
        });
    }
}
 