
import java.awt.Color;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author User's
 */
public class AirlineReservation extends javax.swing.JFrame {

    int size = 10,
        size2 = 10,
        value = 1,
        front= -1,
        rear= -1,
        rear2=- 1,
        front2 =-1; 
           
     int seata = 10, seatb = 10;
     String customers[]= new String[size], contact[] = new String [size], sex[] = new String [size], classtypes[] = new String [size];
     int age [] = new int[size];
      String customers2[]= new String[size], contact2[] = new String [size], sex2[] = new String [size], classtypes2[] = new String [size];
     int age2 [] = new int[size];
         String name1;
         int age1;
         String contact1;
         String sex1;
         String class1;  
         String SAge;
           String name12;
         int age12;
         String contact12;
         String sex12;
         String class12;  
         String SAge2;
     
     
     
    public AirlineReservation() {
        initComponents();
        
    }
     public void enqueue() {
          name1 = txtname.getText();
          age1 = Integer.valueOf(txtage.getText());
          contact1 = txtcontact.getText();
          sex1 = jComboBox2.getSelectedItem().toString();
          class1 =jComboBox1.getSelectedItem().toString();
          SAge = String.valueOf(age1);
         
         if ((rear+1)%size==front) 
        {
            JOptionPane.showMessageDialog(this,"Class A is Full.","Alert",JOptionPane.WARNING_MESSAGE);
        } else {
             if (front== -1) 
            {
                front= 0;
            }
          if(seata<=10){
             rear= (rear+1)%size; 
             customers[rear]= name1;
             age [rear] = age1;
             contact[rear] = contact1;
             sex[rear] = sex1;
             classtypes [rear] = class1;
             
            list1.add("===============================");
            list1.add("Name: " + name1);
            list1.add("Age: " + String.valueOf(age1));
            list1.add("Contact Number: "+ contact1);
            list1.add("CLASS: " + class1);
            list1.add("===============================");
           
             
             
             }    
           }
     }
      public void enqueue1() {
          name12 = txtname.getText();
          age12 = Integer.valueOf(txtage.getText());
          contact12 = txtcontact.getText();
          sex12 = jComboBox2.getSelectedItem().toString();
          class12 =jComboBox1.getSelectedItem().toString(); 
            SAge2 = String.valueOf(age12);
         if ((rear2+1)%size2==front2){
                                 
            JOptionPane.showMessageDialog(this,"Class B is Full.","Alert",JOptionPane.WARNING_MESSAGE);
        } else {
             if (front2== -1) 
            {
                front2= 0;
            }
          if(seatb<=10){
             rear2= (rear2+1)%size2; 
             customers2[rear2]= name12;
             age2 [rear2] = age12;
             contact2[rear2] = contact12;
             sex2[rear2] = sex12;
             classtypes2 [rear2] = class12;
             
            list2.add("===============================");
            list2.add("Name: " + name12);
            list2.add("Age: " + String.valueOf(age12));
            list2.add("Contact Number: "+ contact12);
            list2.add("CLASS: " + class12);
            list2.add("===============================");

             }    
           }
     }
       public void dequeue() {
    
        if (front==-1) 
        {
            JOptionPane.showMessageDialog(this,"Queue is Empty.","Alert",JOptionPane.WARNING_MESSAGE);
        } 
        else 
        {
            name1= customers[front];
            age1 = age[front];
            contact1 = contact[front];
            sex1 = sex[front];
            class1 = classtypes[front];
       list1.remove("===============================");
            list1.remove("Name: " + name1);
            list1.remove("Age: " + String.valueOf(age1));
            list1.remove("Contact Number: "+ contact1);
            list1.remove("CLASS: " + class1);  
            list1.remove("===============================");

            if (front==rear) 
            {
                front= -1;
                rear= -1;
            } 
            else 
            {
                front= (front + 1)%size; 
            }
        }
    }
       public void dequeue1() {
    
        if (front2==-1) 
        {
            JOptionPane.showMessageDialog(this,"Queue is Empty.","Alert",JOptionPane.WARNING_MESSAGE);
        } 
        else 
        {
            name12= customers2[front2];
            age12 = age2[front2];
            contact12 = contact2[front2];
            sex12 = sex2[front2];
            class12 = classtypes2[front2];
       list2.remove("===============================");
            list2.remove("Name: " + name12);
            list2.remove("Age: " + String.valueOf(age12));
            list2.remove("Contact Number: "+ contact12);
            list2.remove("CLASS: " + class12);    
            list2.remove("===============================");

            if (front2==rear2) 
            {
                front2= -1;
                rear2= -1;
            } 
            else 
            {
                front2= (front2 + 1)%size2; 
            }
        }
    }
       void table(){
           
        
         String table[] ={"F0012",name1,SAge,sex1,contact1,class1};
         DefaultTableModel tb1  = (DefaultTableModel)jTable1.getModel();
         tb1.addRow(table);
       }
       void table1(){
           
        
         String table[] ={"F0012",name12,SAge2,sex12,contact12,class12};
         DefaultTableModel tb1  = (DefaultTableModel)jTable1.getModel();
         tb1.addRow(table);
       }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        txtcontact = new javax.swing.JTextField();
        txtname = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        txtage = new javax.swing.JTextField();
        jComboBox1 = new javax.swing.JComboBox<>();
        jComboBox2 = new javax.swing.JComboBox<>();
        jButton1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        list1 = new java.awt.List();
        list2 = new java.awt.List();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton5 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel7.setBackground(new java.awt.Color(96, 150, 180));

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1110, Short.MAX_VALUE)
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 40, Short.MAX_VALUE)
        );

        jPanel2.add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1110, 40));

        jPanel1.setBackground(new java.awt.Color(189, 205, 214));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel3.setBackground(new java.awt.Color(147, 191, 207));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 0, 0));
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanel3.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 380, 250, 40));

        txtcontact.setFont(new java.awt.Font("MS Reference Sans Serif", 1, 14)); // NOI18N
        txtcontact.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtcontactKeyPressed(evt);
            }
        });
        jPanel3.add(txtcontact, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 380, 250, 40));

        txtname.setFont(new java.awt.Font("MS Reference Sans Serif", 1, 14)); // NOI18N
        jPanel3.add(txtname, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 170, 250, 40));

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 0, 0));
        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanel3.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 240, 240, 40));

        txtage.setFont(new java.awt.Font("MS Reference Sans Serif", 1, 14)); // NOI18N
        txtage.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtageKeyPressed(evt);
            }
        });
        jPanel3.add(txtage, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 240, 250, 40));

        jComboBox1.setFont(new java.awt.Font("MS Reference Sans Serif", 1, 14)); // NOI18N
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "CLASS A", "CLASS B" }));
        jPanel3.add(jComboBox1, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 450, 250, 40));

        jComboBox2.setFont(new java.awt.Font("MS Reference Sans Serif", 1, 14)); // NOI18N
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Male", "Female" }));
        jPanel3.add(jComboBox2, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 310, 250, 40));

        jButton1.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        jButton1.setText("MAKE RESERVATION");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 540, -1, 30));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1.setText("Class:   ");
        jPanel3.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 450, 80, 40));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel2.setText("Name:   ");
        jPanel3.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 170, 80, 40));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel3.setText("Age:  ");
        jPanel3.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 240, 80, 40));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel4.setText("Sex:   ");
        jPanel3.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 310, 80, 40));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("Contact:   ");
        jPanel3.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 380, 80, 40));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("FLIGHT - F0012");
        jPanel3.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 350, -1));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setText("MANILA TO BORACAY");
        jPanel3.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 50, 360, 30));

        jButton4.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        jButton4.setText("TRANSACTION");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 610, 160, 30));

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 23)); // NOI18N
        jLabel12.setText("DEPARTURE TIME: 11:00 PM");
        jPanel3.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, 360, 30));

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 350, 700));

        list1.setFont(new java.awt.Font("MS UI Gothic", 1, 14)); // NOI18N
        jPanel1.add(list1, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 80, 260, 560));

        list2.setFont(new java.awt.Font("MS UI Gothic", 1, 14)); // NOI18N
        jPanel1.add(list2, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 80, 260, 560));

        jButton2.setBackground(new java.awt.Color(79, 112, 156));
        jButton2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("Process Waiting List");
        jButton2.setOpaque(false);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 650, -1, -1));

        jButton3.setBackground(new java.awt.Color(79, 112, 156));
        jButton3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.setText("Process Waiting List");
        jButton3.setOpaque(false);
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 650, -1, -1));

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 28)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 31, 63));
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setText("Queue - Class B");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(749, 30, 260, -1));

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 28)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 31, 63));
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setText("Queue - Class A");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(449, 30, 260, -1));

        jTabbedPane1.addTab("tab3", jPanel1);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "FLIGHT", "NAME", "AGE", "SEX", "CONTACT", "CLASS"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);
        if (jTable1.getColumnModel().getColumnCount() > 0) {
            jTable1.getColumnModel().getColumn(0).setResizable(false);
            jTable1.getColumnModel().getColumn(1).setResizable(false);
            jTable1.getColumnModel().getColumn(2).setResizable(false);
            jTable1.getColumnModel().getColumn(3).setResizable(false);
            jTable1.getColumnModel().getColumn(4).setResizable(false);
            jTable1.getColumnModel().getColumn(5).setResizable(false);
        }

        jButton5.setText("BACK");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(52, 52, 52)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jButton5)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 998, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(55, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 593, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton5)
                .addContainerGap(43, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab2", jPanel4);

        jPanel2.add(jTabbedPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 1110, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
      String class1 = jComboBox1.getSelectedItem().toString(); 
    String name1 = txtname.getText();
    String age1 = txtage.getText();
    String contact1 = txtcontact.getText();

    if (name1.isEmpty() || age1.isEmpty() || contact1.isEmpty()) {
        JOptionPane.showMessageDialog(this, "PLEASE FILL UP ALL INFORMATION NEEDED", "Alert", JOptionPane.WARNING_MESSAGE);
    } else {
        if (class1.equalsIgnoreCase("Class A")) {
            enqueue();
            txtname.setText("");
            txtage.setText("");
            txtcontact.setText("");
        } else {
            enqueue1();
             txtname.setText("");
            txtage.setText("");
            txtcontact.setText("");
        }
    }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
       
        if(list1.getItemCount()==0){
            JOptionPane.showMessageDialog(this, "No Record Found", "Alert", JOptionPane.WARNING_MESSAGE);
        }else{
             dequeue();
            table();
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
    

        if(list2.getItemCount()==0){
             JOptionPane.showMessageDialog(this, "No Record Found", "Alert", JOptionPane.WARNING_MESSAGE);
        }else{
           dequeue1();
            table1();
        }
        
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
     jTabbedPane1.setSelectedIndex(1);
    }//GEN-LAST:event_jButton4ActionPerformed

    private void txtageKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtageKeyPressed
        // TODO add your handling code here:
        char c = evt.getKeyChar();
        if(Character.isLetter(c)){
            txtage.setEditable(false);
            jLabel11.setText("Input Number Only");
        } else{
            jLabel11.setText("");
             txtage.setEditable(true);
             
        }
    }//GEN-LAST:event_txtageKeyPressed

    private void txtcontactKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtcontactKeyPressed
        // TODO add your handling code here:
        char d = evt.getKeyChar();
        if(Character.isLetter(d)){
            txtcontact.setEditable(false);
          
            jLabel10.setText("Input Number Only");
        } else{
            jLabel10.setText("");
             txtcontact.setEditable(true);
             
        }
    }//GEN-LAST:event_txtcontactKeyPressed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
         jTabbedPane1.setSelectedIndex(0);
    }//GEN-LAST:event_jButton5ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AirlineReservation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AirlineReservation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AirlineReservation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AirlineReservation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AirlineReservation().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable jTable1;
    private java.awt.List list1;
    private java.awt.List list2;
    private javax.swing.JTextField txtage;
    private javax.swing.JTextField txtcontact;
    private javax.swing.JTextField txtname;
    // End of variables declaration//GEN-END:variables
}
